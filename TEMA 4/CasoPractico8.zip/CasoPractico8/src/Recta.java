public class Recta extends Punto{
    public Recta(double x, double y) {
        super(x, y);
    }
}
